# SnowFlake

git add .
git commit -m "обновочка"
git push origin main
